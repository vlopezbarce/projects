// Valeria López Barcelata A00833578
// Proyecto Integrador (Situación Problema)

#ifndef Video_h
#define Video_h
#include <iostream>
using namespace std;

class Video{
private:
  string nombre;
  string genero;
  int duracion;
  double calificacion;

public:
  Video();
  Video(string _nombre, string _genero, int _duracion, double _calificacion);
  string getNombre();
  string getGenero();
  int getDuracion();
  double getCalificacion();
  void setNombre(string _nombre);
  void setGenero(string _genero);
  void setDuracion(int _duracion);
  void setCalificacion(double _calificacion);

  // Métodos virtuales (Clases Abstractas)
  virtual void mostrar(); 
  virtual void operator++();
  virtual void operator--();
};

// Métodos constructores
Video::Video(){
  nombre = " ";
  genero = " ";
  duracion = 0;
  calificacion = 0;
}
Video::Video(string _nombre, string _genero, int _duracion, double _calificacion){
  nombre = _nombre;
  genero = _genero;
  duracion = _duracion;
  calificacion = _calificacion;
}

// Métodos de acceso
string Video::getNombre(){
  return nombre;
}
string Video::getGenero(){
  return genero;
}
int Video::getDuracion(){
  return duracion;
}
double Video::getCalificacion(){
  return calificacion;
}

// Métodos modificadores
void Video::setNombre(string _nombre){
  nombre = _nombre;
}
void Video::setGenero(string _genero){
  genero = _genero;
}
void Video::setDuracion(int _duracion){
  duracion = _duracion;
}
void Video::setCalificacion(double _calificacion){
  calificacion = _calificacion;
}

// Otros métodos
void Video::mostrar(){
  cout << nombre << " " << genero << " " << duracion << " " << calificacion << endl;
}
void Video::operator++(){
  calificacion++;
  if (calificacion > 5){
    calificacion = 5;
  }
  cout << "Nueva calificacion: " << calificacion << endl;
}
void Video::operator--(){
  calificacion--;
  if (calificacion < 0){
    calificacion = 0;
  }
  cout << "Nueva calificacion: " << calificacion << endl;
}

// Subclase Serie (Herencia)
class Serie : public Video{
private:
  int IDSerie;

public:
  Serie();
  Serie(int _IDSerie, string _nombre, string _genero, int _duracion, double _calificacion);
  int getIDSerie();
  void setIDSerie(int _IDSerie);
  void mostrar();
};

Serie::Serie(){
  IDSerie = -1;
}
Serie::Serie(int _IDSerie, string _nombre, string _genero, int _duracion, double _calificacion):Video(_nombre, _genero, _duracion, _calificacion){
  IDSerie = _IDSerie;
}
int Serie::getIDSerie(){
  return IDSerie;
}
void Serie::setIDSerie(int _IDSerie){
  IDSerie = _IDSerie;
}
void Serie::mostrar(){ // Sobreescritura de métodos
  cout << IDSerie << " " << getNombre() << " ";
  cout << getCalificacion() << "/5" << endl;
  cout << "Genero: " << getGenero() << "  ";
  cout << "Duracion: " << getDuracion() << " min." << endl << endl;
}

// Subclase Película (Herencia)
class Pelicula : public Video{
private:
  int IDPelicula;

public:
  Pelicula();
  Pelicula(int _IDPelicula, string _nombre, string _genero, int _duracion, double _calificacion);
  int getIDPelicula();
  void setPelicula(int _IDPelicula);
  void mostrar();
};

Pelicula::Pelicula(){
  IDPelicula = -1;
}
Pelicula::Pelicula(int _IDPelicula, string _nombre, string _genero, int _duracion, double _calificacion):Video(_nombre, _genero, _duracion, _calificacion){
  IDPelicula = _IDPelicula;
}
int Pelicula::getIDPelicula(){
  return IDPelicula;
}
void Pelicula::setPelicula(int _IDPelicula){
  IDPelicula = _IDPelicula;
}
void Pelicula::mostrar(){ // Sobreescritura de métodos
  cout << IDPelicula << " " << getNombre() << " ";
  cout << getCalificacion() << "/5" << endl;
  cout << "Genero: " << getGenero() << "  ";
  cout << "Duracion: " << getDuracion() << " min." << endl << endl;
}

#endif
