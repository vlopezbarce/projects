// Valeria López Barcelata A00833578
// Avance 3

#ifndef Episodio_hpp
#define Episodio_hpp

#include <iostream>
#include <stdio.h>
#include <string>
using namespace std;

class Episodio{
  private:
    string titulo;
    int temporada;
    double calificacionPromedio;

  public:
    // Métodos constructores
    Episodio();
    Episodio(string _titulo, int _temporada, double _calificacionPromedio);
    
    // Método destructor
    ~Episodio();

    // Métodos modificadores
    void setTitulo(string _titulo);
    void setTemporada(int _temporada);
    void setCalificacion(double _calificacionPromedio);

    // Métodos de acceso
    string getTitulo();
    int getTemporada();
    double getCalificacion();

    string str();
};

#endif