// TC1030. Programación orientada a objetos (Grupo 300)
// Proyecto Integrador: Situación Problema
// Valeria López Barcelata A00833578
// Profa. Gabriela Zamora Leal
// 15 de junio del 2022

#include <fstream>
#include <iostream>
#include <limits>
using namespace std;
#include "Episodio.h"
#include "Video.h"

// Buscar serie por nombre (Sobrecarga de métodos)
bool buscaTitulo(string buscaNom, Serie Series[], int n, int &ID){
  for (int i = 0; i < n; i++){
    if (buscaNom == Series[i].getNombre()){
      ID = Series[i].getIDSerie();
      return true;
    }
  }
  cout << "El titulo no existe " << endl;
  return false;
}
// Buscar serie o película por nombre 
bool buscaTitulo(string buscaNom, Serie Series[], int nSeries, Pelicula Peliculas[], int nPeliculas, int &IDSerie, int &IDPelicula){
  for (int i = 0; i < nSeries; i++){
    if (buscaNom == Series[i].getNombre()){
      IDSerie = Series[i].getIDSerie();
      return true;
    }
  }
  for (int i = 0; i < nPeliculas; i++){
    if (buscaNom == Peliculas[i].getNombre()){
      IDPelicula = Peliculas[i].getIDPelicula();
      return true;
    }
  }
  cout << "El titulo no existe " << endl;
  return false;
}

// Calificar una serie o película (Polimorfismo)
void calificaTitulo(Serie Series[], int n, int ID){
  int opcion;
  double calif;
  cout << "\n1. Subir calificacion"
  << "\n2. Bajar calificacion"
  << "\n3. Ingresar calificacion" << endl;
  cin >> opcion;
  switch (opcion){
    case 1:{ // Sobrecarga de operador ++
      ++Series[ID-1];
      break;
    }
    case 2:{ // Sobrecarga de operador --
      --Series[ID-1];
      break;
    }
    case 3:{ // Manejo de excepciones
      try{
        cout << "Califica la serie: ";
        cin >> calif;
        if(!cin || calif < 0 || calif > 5){
          throw "a";
        }
        else{
          Series[ID-1].setCalificacion(calif);
        }
      }
      catch (...){
	      cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Error: Ingresa un valor numerico entre 0 y 5 " << endl;
      }
      break;
    }
  }
}
void calificaTitulo(Pelicula Peliculas[], int n, int ID){
  int opcion;
  double calif;
  cout << "\n1. Subir calificacion"
  << "\n2. Bajar calificacion"
  << "\n3. Ingresar calificacion" << endl;
  cin >> opcion;
  switch (opcion){
    case 1:{ // Sobrecarga de operador ++
      ++Peliculas[ID-1];
      break;
    }
    case 2:{ // Sobrecarga de operador --
      --Peliculas[ID-1];
      break;
    }
    case 3:{ // Manejo de excepciones
      try{
        cout << "Califica la pelicula: ";
        cin >> calif;
        if(!cin || calif < 0 || calif > 5){
          throw "a";
        }
        else{
          Peliculas[ID-1].setCalificacion(calif);
        }
      }
      catch (...){
	      cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Error: Ingresa un valor numerico entre 0 y 5 " << endl;
      }
      break;
    }
  }
}

// Cargar datos de todas las series
void cargarSeries(Serie Series[]){
  Series[0] = Serie(1, "El Juego Del Calamar", "Drama", 485, 4.75);
  Series[1] = Serie(2, "La Casa De Papel", "Accion", 2170, 4.7);
  Series[2] = Serie(3, "Stranger Things", "Misterio", 1920, 4.6);
  Series[3] = Serie(4, "Bridgerton", "Drama", 496, 4.1);
  Series[4] = Serie(5, "Lucifer", "Drama", 4020, 4.4);
}

// Cargar datos de todas las películas
void cargarPeliculas(Pelicula Peliculas[]){
  Peliculas[0] = Pelicula(1, "Alerta Roja", "Accion", 118, 4.35);
  Peliculas[1] = Pelicula(2, "No Miren Arriba", "Drama", 145, 4.05);
  Peliculas[2] = Pelicula(3, "Bird Box", "Misterio", 120, 4.25);
  Peliculas[3] = Pelicula(4, "El Proyecto Adam", "Accion", 106, 4.5);
  Peliculas[4] = Pelicula(5, "Mision De Rescate", "Accion", 117, 4.3);
}

// Cargar datos de los episodios de cada serie
void cargarEpisodios(int ID, Episodio Episodios[]){
  switch (ID){
  case 1:
    Episodios[0] = Episodio("Luz roja, luz verde", 1, 4.8);
    Episodios[1] = Episodio("Infierno", 1, 4.75);
    Episodios[2] = Episodio("El hombre del paraguas", 1, 4.78);
    break;
  case 2:
    Episodios[0] = Episodio("El final del camino", 5, 4.8);
    Episodios[1] = Episodio("¿Crees en la reencarnacion?", 5, 4.5);
    Episodios[2] = Episodio("El espectaculo de la vida", 5, 4.6);
    break;
  case 3:
    Episodios[0] = Episodio("The Hellfire Club", 4, 4.9);
    Episodios[1] = Episodio("Vecna's Curse", 4, 4.75);
    Episodios[2] = Episodio("The Monster and the Superhero", 4, 4.8);
    break;
  case 4:
    Episodios[0] = Episodio("Libertino con todas las letras", 2, 4.4);
    Episodios[1] = Episodio("La carrera ya va a empezar", 2, 4.3);
    Episodios[2] = Episodio("Obsesiones", 2, 4.1);
    break;
  case 5:
    Episodios[0] = Episodio("Aqui nunca cambia nada", 6, 4.5);
    Episodios[1] = Episodio("Muchos traumas", 6, 4.25);
    Episodios[2] = Episodio("Yabba Dabba Do Me", 6, 4.2);
    break;
  }
}

// Desplegar videos y sus datos generales (Polimorfismo)
void mostrarVideos(Serie Series[], int n){
  cout << endl << "Series: " << endl;
  for (int i = 0; i < n; i++){
    Series[i].mostrar();
  }
}
void mostrarVideos(Pelicula Peliculas[], int n){
  cout << endl << "Peliculas: " << endl;
  for (int i = 0; i < n; i++){
    Peliculas[i].mostrar();
  }
}

// Desplegar episodios y datos generales
void mostrarEpisodios(int ID, Serie Series[], Episodio Episodios[], int n){
  cout << endl << "Serie: " << Series[ID-1].getNombre() << endl;
  cout << "Episodios: " << endl;
  for (int i = 0; i < n; i++){
    Episodios[i].mostrar();
  }
}

// Función main
int main(){
  int opcion;
  string buscaNom;
  bool salir = false;
  int nSeries = 5, nPeliculas = 5, nEpisodios = 3;
  int IDSerie = -1, IDPelicula = -1;
  Serie Series[nSeries];
  Pelicula Peliculas[nPeliculas];
  Episodio Episodios[nEpisodios];
  cargarSeries(Series);
  cargarPeliculas(Peliculas);

  cout << "¡Explora el catalogo de Netflix! ->";
  do{ // Menú de opciones
    cout << "\n1. Mostrar series y calificaciones"
    << "\n2. Mostrar episodios de una serie y calificaciones"
    << "\n3. Mostrar peliculas y calificaciones"
    << "\n4. Calificar un video"
    << "\n0. Salir" << endl;
    cin >> opcion;
    switch (opcion){
      case 0:{ // Salir del programa
        salir = true;
        break;
      }
      case 1:{ // Mostrar series
        mostrarVideos(Series, nSeries);
        break;
      }
      case 2:{ // Buscar serie por nombre y mostrar sus episodios
        do{
          cout << "Ingresa el nombre de la serie: ";
          getline(cin >> ws, buscaNom);
        } while (buscaTitulo(buscaNom, Series, nSeries, IDSerie) == false);
        cargarEpisodios(IDSerie, Episodios);
        mostrarEpisodios(IDSerie, Series, Episodios, nEpisodios);
        IDSerie = -1;
        break;
      }
      case 3:{ // Mostrar películas
        mostrarVideos(Peliculas, nPeliculas);
        break;
      }
      case 4:{ // Buscar serie o película por nombre y calificar
        do{
          cout << "Ingresa el nombre del titulo a calificar: ";
          getline(cin >> ws, buscaNom);
        } while (buscaTitulo(buscaNom, Series, nSeries, Peliculas, nPeliculas, IDSerie, IDPelicula) == false);
        if (IDSerie != -1){
          calificaTitulo(Series, nSeries, IDSerie);
        }
        else if (IDPelicula != -1){
          calificaTitulo(Peliculas, nPeliculas, IDPelicula);
        }
        IDSerie = -1, IDPelicula = -1;
        break;
      }
    }
  } while (salir == false);
  return 0;
}