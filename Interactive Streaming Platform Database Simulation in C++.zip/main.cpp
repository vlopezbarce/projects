// Tecnológico de Monterrey
// TC1033. Pensamiento computacional orientado a objetos (Grupo 2)
// Prof. Ma. Guadalupe Roque Díaz De León
// 5 de diciembre del 2021
// Valeria López Barcelata A00833578
// Avance 3: Entrega Final

// Video de ejecución del programa: https://youtu.be/5MOrnkxRE9c

#include <iostream>
#include "Serie.hpp"
#include "Episodio.hpp"
#include "Series.hpp"
using namespace std;

// Leer datos serie y crear un objeto de la clase Serie
Serie leerSerie(){
  string id;
  string titulo;
  string genero;
  int duracion;
  int cantEpisodios;
  int numEpisodio;
  double calificacionPromedio;
  Episodio episodios;

  cout << "Ingresa el ID: ";
  cin >> id;
  cout << "Ingresa el título: ";
  cin >> titulo;
  cout << "Ingresa el género: ";
  cin >> genero;
  cout << "Ingresa la duración (min): ";
  cin >> duracion;
  cout << "Ingresa la cantidad de episodios: ";
  cin >> cantEpisodios;
  cout << "Ingresa la calificación promedio: ";
  cin >> calificacionPromedio;

  // Cantidad de episodios no puede excederse de 5
  if (cantEpisodios > 5){
    cantEpisodios = 5;
  }
  // No se han agregado episodios
  numEpisodio = 0;
  return Serie(id, titulo, genero, duracion, cantEpisodios, calificacionPromedio, numEpisodio, episodios);
}

// Leer datos episodio y crear un objeto de la clase Episodio
Episodio leerEpisodio(){
  string titulo;
  int temporada;
  double calificacionPromedio;

  cout << "Ingresa el título: ";
  cin >> titulo;
  cout << "Ingresa la temporada: ";
  cin >> temporada;
  cout << "Ingresa la calificación promedio: ";
  cin >> calificacionPromedio;

  return Episodio(titulo, temporada, calificacionPromedio);
}

int menu(){
  int opcion;
  cout << endl << "Menú de opciones" <<
  "\n0. Salir" <<
  "\n1. Leer Datos Serie y crear un objeto de la clase Serie" <<
  "\n2. setID(string)" <<
  "\n3. setTitulo(string)" <<
  "\n4. setDuracion(int)" <<
  "\n5. setGenero(string)" <<
  "\n6. setCalificacion(double)" <<
  "\n7. setCantidadEpisodios(int)" <<
  "\n8. Desplegar Serie con el método str()" <<
  "\n9. Leer Datos Episodios y crear un arreglo de la clase Episodios" <<
  "\n10. Desplegar Episodio con el método str()" <<
  "\n11. Borrar último Episodio (delEpisodio)" <<
  "\n12. Casos de Prueba" <<
  "\n13. Cambiar un Episodio (setEpisodio)" <<
  "\n14. Leer Archivos" <<
  "\n15. Calcular calificación promedio de todas las series" <<
  "\n16. reporteFrecuenciasPromedio" <<
  "\nTeclea la opción: ";
  cin >> opcion;
  return opcion;
}

int main(){
    // Declaración de variables
    Serie hoy;
    Episodio ayer;
    Episodio episodios;
    Series series;
    int opcion;
    int duracion;
    int cantEpisodios;
    int calificacionPromedio;
    int temporada;
    int numEpisodio;
    int maxEpisodios;
    int num;
    string id;
    string titulo;
    string genero;
    
    // Diseño de ciclo centinela
    opcion = menu();
    while (opcion != 0){
      switch (opcion){
        case 1:
          hoy = leerSerie();
          break;
        case 2:
          cout << "Ingresa el nuevo ID: ";
          cin >> id;
          hoy.setID(id);
          break;
        case 3:
          cout << "Ingresa el nuevo título: ";
          cin >> titulo;
          hoy.setTitulo(titulo);
          break;
        case 4:
          cout << "Ingresa la nueva duración: ";
          cin >> duracion;
          hoy.setDuracion(duracion);
          break;
        case 5:
          cout << "Ingresa el nuevo género: ";
          cin >> genero;
          hoy.setGenero(genero);
          break;
        case 6:
          cout << "Ingresa la nueva calificación promedio: ";
          cin >> calificacionPromedio;
          hoy.setCalificacion(calificacionPromedio);
          break;
        case 7:
          cout << "Ingresa la nueva cantidad de episodios: ";
          cin >> cantEpisodios;
          hoy.setCantidadEpisodios(cantEpisodios);
          break;
        case 8:
          cout << hoy.str() << endl;
          break;
        case 9:
          maxEpisodios = hoy.getCantidadEpisodios();
          for (int iEpisodios = 0; iEpisodios < maxEpisodios; iEpisodios++){
            cout << "Ingresa los datos del Episodio E" << iEpisodios << endl;
            ayer = leerEpisodio();
            hoy.setEpisodio(iEpisodios, ayer);
          }
          break;
        case 10:
          cout << ayer.str() << endl;
          break;
        case 11:
          hoy.delEpisodio(episodios);
          break;
        case 12:
          hoy.setCantidadEpisodios(0);
          hoy.addEpisodio(Episodio("Clases", 1, 90));
          hoy.addEpisodio(Episodio("Constructores", 1, 90));
          hoy.addEpisodio(Episodio("Composicion", 1, 99.5));
          hoy.addEpisodio(Episodio("Arreglos", 1, 99.5));
          hoy.addEpisodio(Episodio("Clase Arreglos", 1, 100));

          num = 100;
          ayer = hoy.getEpisodio(num);
          if (num == -1){
            cout << "No existe el episodio!\n" << ayer.str() << endl;
          }
          else{
            cout << "Si existe el episodio 1" << ayer.str() << endl;
          }

          hoy.addEpisodio(Episodio("Calificacion Final", 1, 100));
          hoy.calculaCalificacionPromedio();
          cout << hoy.str() << endl;
          hoy.delEpisodio(episodios);
          hoy.addEpisodio(Episodio("Calificacion Final", 1, 100));
          cout << hoy.str() << endl;
          break;
        case 13:
          numEpisodio = 0;
          cout << "Ingresa el número del episodio que deseas cambiar: ";
          cin >> numEpisodio;
          cout << "Ingresa los datos del Episodio E" << --numEpisodio << endl;
          ayer = leerEpisodio();
          hoy.setEpisodio(numEpisodio, ayer);
          break;
        case 14:
          series.leerArchivo();
          break;
        case 15:
          series.calcularCalificacionPromedioSerie();
          break;
        case 16:
          series.reporteFrecuenciasYPromedioSeries();
          break;
        default:
          break;
      }
    opcion = menu();
  }
    return 0;
}