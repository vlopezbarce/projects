// Valeria López Barcelata A00833578
// Avance 3

#include "Serie.hpp"
using namespace std;

// Constructores de la clase
Serie::Serie(){
    id = "000";
    titulo = "Programación Orientada a Objetos";
    genero = "Innovación";
    duracion = 120;
    cantEpisodios = 5;
    calificacionPromedio = 100;
    numEpisodio = 0;
}
Serie::Serie(string _id, string _titulo, string _genero, int _duracion, int _cantEpisodios, double _calificacionPromedio, int _numEpisodio, Episodio _episodios){
    id = _id;
    titulo = _titulo;
    genero = _genero;
    duracion = _duracion;
    cantEpisodios = _cantEpisodios;
    calificacionPromedio = _calificacionPromedio;
    numEpisodio = _numEpisodio;
    episodios[0] = _episodios;
}

// Métodos modificadores - cambiar el valor de un atributo
void Serie::setID(string _id){
    id = _id;
}
void Serie::setTitulo(string _titulo){
    titulo = _titulo;
}
void Serie::setGenero(string _genero){
    genero = _genero;
}
void Serie::setDuracion(int _duracion){
    duracion = _duracion;
}
// Cantidad de episodios no puede exceder el espacio del arreglo episodios[5]
void Serie::setCantidadEpisodios(int _cantEpisodios){
  if (_cantEpisodios <= 5){
    cantEpisodios = _cantEpisodios;
  }
  else{
    cout << "Cantidad de episodios excede el espacio del arreglo episodios, se han establecido 5 episodios" << endl;
    cantEpisodios = 5;
  }
}
void Serie::setCalificacion(double _calificacionPromedio){
    calificacionPromedio = _calificacionPromedio;
}
// Cambiar cualquier episodio dentro del arreglo existente de episodios
// Actualizar cantidad de episodios si es que no existían
void Serie::setEpisodio(int &_numEpisodio, Episodio _episodios){
  if (_numEpisodio >= 0 && _numEpisodio < cantEpisodios){
    episodios[_numEpisodio] = _episodios;
    if (numEpisodio != cantEpisodios){
      numEpisodio++;
    }
  }
  else{
    cout << "El episodio no existe" << endl;
    numEpisodio = -1;
  }
}
void Serie::calculaCalificacionPromedio(){
  double acum = 0;
  for(int iEpisodio = 0; iEpisodio < cantEpisodios; iEpisodio++){
    acum = acum + episodios[iEpisodio].getCalificacion();
  }
  if (numEpisodio > 0){
    calificacionPromedio = acum / cantEpisodios;
  }
  else{
    calificacionPromedio = 0;
  }
}
// Actualizar cantidad total con cantidad de episodios agregados
void Serie::addEpisodio(Episodio _episodios){
  if (numEpisodio < 5){
    episodios[numEpisodio] = _episodios;
    cantEpisodios = ++numEpisodio;
  }
  else{
    cout << "No se pudo añadir el episodio " << _episodios.str() << endl;
  }
}
// Si existen episodios borrar el anterior
// Llenar el episodio anterior con episodio vacío (la cantidad total no cambia)
void Serie::delEpisodio(Episodio _episodios){
    if (numEpisodio > 0){
      numEpisodio--;
      cout << "Se eliminó el episodio: " << episodios[cantEpisodios - 1].str() << endl;
      Episodio epi;
      episodios[numEpisodio] = epi;
    }
    else
      cout << "No se pudo eliminar el episodio " << endl;
}

// Métodos de acceso - retornan el valor de un atributo
string Serie::getID(){
    return id;
}
string Serie::getTitulo(){
    return titulo;
}
string Serie::getGenero(){
    return genero;
}
int Serie::getDuracion(){
    return duracion;
}
int Serie::getCantidadEpisodios(){
    return cantEpisodios;
}
double Serie::getCalificacion(){
    return calificacionPromedio;
}
Episodio Serie::getEpisodio(int &numEpisodio){
  Episodio epi;
  if (numEpisodio >= 0 && numEpisodio < cantEpisodios){
    return episodios[numEpisodio];
  }
  else{
    cout << "El episodio no existe" << endl;
    numEpisodio = -1;
    return epi;
  }
}

// Método que retorna todos los atributos concatenados y separados por ,
string Serie::str(){
    string acum = "";

    // Si existen episodios se desplegan junto con la serie
    if (numEpisodio > 0){
      for (int iEpisodios = 0; iEpisodios < cantEpisodios; iEpisodios++){
          acum = acum + "E" + to_string(iEpisodios) + episodios[iEpisodios].str() + "\n";
      }
      return id + ", " + titulo + ", " + to_string(duracion) + ", " + genero + ", " + to_string(calificacionPromedio) + ", " + to_string(cantEpisodios) + "\n" + acum;
    }
    // Solamente se desplega la serie si no existen episodios
    else{
      return id + ", " + titulo + ", " + to_string(duracion) + ", " + genero + ", " + to_string(calificacionPromedio) + ", " + to_string(cantEpisodios) + "\n";
    }
}