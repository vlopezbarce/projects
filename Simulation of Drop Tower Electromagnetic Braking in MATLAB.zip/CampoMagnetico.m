clc;
clear;

% Modelación computacional de sistemas electromagnéticos
% Reto Fase 1. Investigación / Simulación

% Equipo 4: Not Gauss

% Integrantes:
% Marco Antonio Rodríguez Amezcua - A00834672
% Manuel José Ortiz Urueña – A00832807
% Isabella Garduño Horneffer – A00833573
% Valeria López Barcelata – A00833578

% Simulación de Campo Magnético generado por una espira circular
%--------------------------------------------------------------------------

% Establecer coordenadas en el plano YZ
Y = 0:0.1:10;
Z = 0:0.1:10;
[y, z] = meshgrid(Y,Z);

% Establecer valores de constantes:

a = 1; % Radio de la espira
I = 5; % Corriente que fluye a través de la espira
mu = 4*pi*10^(-7); % Constante de permitividad

% Cálculo de variable m obtenida mediante equivalencias con la tabla de
% integrales elípticas de Good
m = (4*a.*y)./(a^2 + y.^2 + z.^2 + 2*a.*y);

% Aplicando la Ley de Biot-Savart
c = (mu*I*a)./((2*pi).*(2*a.*y).^(3/2));

% Calculando componentes del campo magnético en By y en Bz mediante
% la resolución de integrales elípticas
[K, E] = ellipke(m);
By = c.*z.*(-sqrt(2.*m).*K + ((2-m)./(2-2.*m)).*sqrt(2.*m).*E);
Bz = c.*(a.*(m./(2-2.*m)).*sqrt(2.*m).*E + y.*sqrt(2.*m).*K - y.*((2-m)./(2-2.*m)).*sqrt(2.*m).*E);

% Agregando vectores para el eje Z:
for i=1:length(Z)
    By(i,1) = 0;
    Bz(i,1) = (mu*I*a^2)/(2*(a^2 + Z(i)^2)^(3/2));
end

% Normalizando los vectores By y Bz respecto al campo magnético B
B = sqrt(By.^2 + Bz.^2);
By = By./ B;
Bz = Bz./ B;

% Graficando la espira y el campo magnético que genera
hold on
quiver(y, z, By, Bz, 0.5, 'b')
quiver(-y, z, -By, Bz, 0.5,'b')
quiver(y, -z, -By, Bz, 0.5, 'b')
quiver(-y, -z, By, Bz, 0.5, 'b')
pos = [-a/2, -0.1/2, a, 0.1];
rectangle('Position',pos,'Curvature',[1 1],'EdgeColor','b','LineWidth',1.5)
hold off
axis([-a-1 a+1 -a-1 a+1])
title('Campo magnético producido por una espira')
xlabel('Eje Y')
ylabel('Eje Z')