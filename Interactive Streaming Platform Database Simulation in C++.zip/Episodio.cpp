// Valeria López Barcelata A00833578
// Avance 3

#include "Episodio.hpp"
using namespace std;

// Métodos constructores
Episodio::Episodio(){
    titulo = "Episodio";
    temporada = 1;
    calificacionPromedio = 100;
}

Episodio::Episodio(string _titulo, int _temporada, double _calificacionPromedio){
    titulo = _titulo;
    temporada = _temporada;
    calificacionPromedio = _calificacionPromedio;
}

// Método destructor
Episodio::~Episodio(){
}

// Métodos modificadores
void Episodio::setTitulo(string _titulo){
    titulo = _titulo;
}
void Episodio::setTemporada(int _temporada){
    temporada = _temporada;
}
void Episodio::setCalificacion(double _calificacionPromedio){
    calificacionPromedio = _calificacionPromedio;
}

// Métodos de acceso
string Episodio::getTitulo(){
    return titulo;
}
int Episodio::getTemporada(){
    return temporada;
}
double Episodio::getCalificacion(){
    return calificacionPromedio;
}

string Episodio::str(){
    return titulo + ", " + to_string(temporada) + ", " + to_string(calificacionPromedio);
}