clear
clearvars

% ----------------Declaraciones iniciales------------------

% coeficiente de friccion

miu = 1.1;

% masa del coche 

m = 800;

% trayectorias de derrape 

derrape1 = @(x) -1.9092*10.^-5 * x + 1200.9756;

derrape2 = @(x) 2.3606*10.^-5 * x + 3529.05;


% Punto inicial y punto final
A = [300, 2300];
B = [2800, 2400];

% Pocicion inicia del coche
C = A;

% Puntos por donde pasa la curva
P1 = [1000, 1300];
P2 = [1710, 2750];

x = [A(1), B(1), P1(1), P2(1)];
y = [A(2), B(2), P1(2), P2(2)];

% Diseño de la curva
coefs = polyfit(x, y, 3);

a = coefs(1);
b = coefs(2);
c = coefs(3);
d = coefs(4);

% Función principal
f = @(x) a.*x.^3 + b.*x.^2 + c.*x + d;
fprima = @(x) 3.*a.*x.^2 + 2.*b.*x + c;
f2prima = @(x) 6.*a.*x + 2.*b;

% Puntos máximos y mínimos
fprimaa = 3.*a;
fprimab = 2.*b;
fprimac = c;
s = [fprimaa, fprimab, fprimac];
t = roots(s);

maximoy = a.*t(1).^3 + b.*t(1).^2 + c.*t(1) + d;
minimoy = a.*t(2).^3 + b.*t(2).^2 + c.*t(2) + d;
maximo = [t(1), maximoy];
minimo = [t(2), minimoy];

% Radio de curvatura
x = linspace(A(1), B(1), 100);
radios = (1 + fprima(x) .^ 2) .^ 1.5 ./ abs(f2prima(x));
radioMinimo = min(radios);

% Longitud de la curva
len = @(x) sqrt(1 + fprima(x) .^ 2);
longitud = integral(len, 300, 2800);

% Variables plot
bg = figure();
bg.WindowState = 'maximized';
set(bg,'Color','#e8e8e8')

% escenario a simular 

escenario = 0;

while escenario ~= 1 && escenario ~= 2 && escenario ~= 3
    disp('Que escenario desea simular?')
    disp('(1- sin errores) ')
    disp('(2- descarrilamiento en gradas primeras) ')
    disp('(3- descarrilamiento en gradas segundas)' )
    escenario = input('opcion: ');
end
% Inicia la animacion

% perdida de energia en calor 
if escenario == 1
    while C(1) < B(1)
        plot(0,0)
        hold on
        plot(5000,5000)
        set(gca,'Color','#e8e8e8')
        fplot(f, [300 2800],'Color','#868686','LineWidth',30)
        fplot(f, [300 2800],'--w','LineWidth',1)
        plot(A(1),A(2),'.g','MarkerSize',50)
        plot(B(1),B(2),'.r','MarkerSize',50)
        plot(C(1), f(C(1)), '.b', 'MarkerSize', 56)
        plot(5000,5000)
        
        % Indicador de escenario
        
        text(2000, 4500, 'Escenario 1')

        % indicadores de pocicion

        text(3500, 4500, sprintf('X position (m): %0.5e', C(1)));
        text(3500, 4300, sprintf('Y position (m): %0.5e', f(C(1))));

        % indicadores de velocidad

        text(3500, 4100, sprintf('X velocity (ms^-1): %0.5e', 10.0));
        text(3500, 3900, sprintf('Y velocity (ms^-1): %0.5e', fprima(C(1))*10));
    
        % indicadores de aceleracion 
    
        text(3500, 3700, sprintf('X acceleration (ms^-2): %0.5e', 0));
        text(3500, 3500, sprintf('Y acceleration (ms^-2): %0.5e', f2prima(C(1))*10));
    
        % kinetic energy 
        vel = sqrt(10.^2 + (fprima(C(1))*10).^2);
        ke = (m * vel.^2) / 2;
        text(3500, 3300, sprintf('KE (J): %0.5e', ke));
    
        % perdida de energia en calor
    
        loss = ke / (m * 9.81 * miu);
        text(3500, 3100, sprintf('Energy loss (J): %0.5e', loss));

        % se renderizan las gradas 
        rectangle('Position', [779  930.96 20 10])
        rectangle('Position', [2314.58 3789.05 20 10])
      
        % refrescamos la pocicion
        hold off
        pause(0.01)
        C(1) = C(1) + 10;
    end
end

if escenario == 2 
    while C(1) < 1500
        plot(0,0)
        hold on
        plot(5000,5000)
        set(gca,'Color','#e8e8e8')
        fplot(f, [300 2800],'Color','#868686','LineWidth',30)
        fplot(f, [300 2800],'--w','LineWidth',1)
        plot(A(1),A(2),'.g','MarkerSize',50)
        plot(B(1),B(2),'.r','MarkerSize',50)
        if C(1) < 819
            plot(C(1), f(C(1)), '.b', 'MarkerSize', 56)
        else
            plot(C(1), derrape1(C(1)), '.b', 'MarkerSize', 56)
        end

        plot(5000,5000)
     
        % indicadores de escenario 
        
        text(2000, 4500, 'Escenario 2')

        
        % indicadores de pocicion

        text(3500, 4500, sprintf('X position (m): %0.5e', C(1)));
        text(3500, 4300, sprintf('Y position (m): %0.5e', f(C(1))));

        % indicadores de velocidad

        text(3500, 4100, sprintf('X velocity (ms^-1): %0.5e', 10.0));
        text(3500, 3900, sprintf('Y velocity (ms^-1): %0.5e', fprima(C(1))*10));
    
        % indicadores de aceleracion 
    
        text(3500, 3700, sprintf('X acceleration (ms^-2): %0.5e', 0));
        text(3500, 3500, sprintf('Y acceleration (ms^-2): %0.5e', f2prima(C(1))*10));
    
        % kinetic energy 
        vel = sqrt(10.^2 + (fprima(C(1))*10).^2);
        ke = (m * vel.^2) / 2;
        text(3500, 3300, sprintf('KE (J): %0.5e', ke));
    
        % perdida de energia en calor
    
        loss = ke / (m * 9.81 * miu);
        text(3500, 3100, sprintf('Energy loss (J): %0.5e', loss));

        % se renderizan las gradas 
        rectangle('Position', [779  930.96 20 10])
        rectangle('Position', [2314.58 3789.05 20 10])
      
        % refrescamos la pocicion
        hold off
        pause(0.01)
        C(1) = C(1) + 10;
    end
end

if escenario == 3 
    while C(1) < 2900
        plot(0,0)
        hold on
        plot(5000,5000)
        set(gca,'Color','#e8e8e8')
        fplot(f, [300 2800],'Color','#868686','LineWidth',30)
        fplot(f, [300 2800],'--w','LineWidth',1)
        plot(A(1),A(2),'.g','MarkerSize',50)
        plot(B(1),B(2),'.r','MarkerSize',50)
        
        if C(1) < 2275.58
            plot(C(1), f(C(1)), '.b', 'MarkerSize', 56)
        else
            plot(C(1), derrape2(C(1)), '.b', 'MarkerSize', 56)
        end
        
        plot(5000,5000)
     
        % indicadores de escenario 
        
        text(2000, 4500, 'Escenario 3')

        % indicadores de pocicion

        text(3500, 4500, sprintf('X position (m): %0.5e', C(1)));
        text(3500, 4300, sprintf('Y position (m): %0.5e', f(C(1))));

        % indicadores de velocidad

        text(3500, 4100, sprintf('X velocity (ms^-1): %0.5e', 10.0));
        text(3500, 3900, sprintf('Y velocity (ms^-1): %0.5e', fprima(C(1))*10));
    
        % indicadores de aceleracion 
    
        text(3500, 3700, sprintf('X acceleration (ms^-2): %0.5e', 0));
        text(3500, 3500, sprintf('Y acceleration (ms^-2): %0.5e', f2prima(C(1))*10));
    
        % kinetic energy 
        vel = sqrt(10.^2 + (fprima(C(1))*10).^2);
        ke = (m * vel.^2) / 2;
        text(3500, 3300, sprintf('KE (J): %0.5e', ke));
    
        % perdida de energia en calor
    
        loss = ke / (m * 9.81 * miu);
        text(3500, 3100, sprintf('Energy loss (J): %0.5e', loss));

        % se renderizan las gradas 
        rectangle('Position', [779  930.96 20 10])
        rectangle('Position', [2314.58 3789.05 20 10])
      
        % refrescamos la pocicion
        hold off
        pause(0.01)
        C(1) = C(1) + 10;
    end
end