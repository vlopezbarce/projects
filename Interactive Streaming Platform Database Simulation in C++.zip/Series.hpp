// Valeria López Barcelata A00833578
// Avance 3

#ifndef Series_hpp
#define Series_hpp

#include <stdio.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "Serie.hpp"

using namespace std;

class Series{
  private:
    Serie arrSeries[100];
    int cantidadSeries;
    
  public:
    // Constructores de la clase
    Series();

    // Métodos modificadores
    void setCantidadSeries(int _cantidadSeries);

    // Métodos de acceso
    int getCantidadSeries();

    // Otros métodos
    void addSerieAlArreglo(Serie _serie);
    void calcularCalificacionPromedioSerie();
    void leerArchivo();
    void reporteFrecuenciasYPromedioSeries();
};

#endif