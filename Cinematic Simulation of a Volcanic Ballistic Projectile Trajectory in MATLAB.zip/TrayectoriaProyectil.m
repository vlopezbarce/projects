clc;
clear;
workspace;

%Tecnológico de Monterrey
%Modelación computacional del movimiento: Reto
%Programación de trayectorias de proyectiles en 2D utilizando un lenguaje de alto nivel (Matlab)
%Profesora Nadia Pérez Goytia

%Equipo Rosa:
%Eugenio Manuel Treviño Sánchez - A00833208
%Valeria López Barcelata - A00833578
%Manuel José Ortiz Urueña - A00832807
%Francisco Aquino - A00833409

%--------------------------------------------------
%Valores iniciales

g = -9.81;
x0 = input('Posición inicial en x (m): ');
y0 = input('Posición inicial en y (m): ');
v0 = input('Rapidez de disparo (m/s): ');
angulo = input('Ángulo de disparo (grados): ');
timestep = input('Paso de tiempo (s): ');

otro_input = 0;
while ~otro_input %La tilde se usa como operación lógica NOT (cero es falso, uno es verdadero, entonces while NOT cero significa while verdadero)
    radio_input = input('Radio del proyectil (m): ');
    if radio_input < 0.08 || radio_input > 0.15 %Rango de radios
        disp('Radio está fuera del rango 0.08-0.15') %Mensaje de error
        otro_input = 0; %Continua el ciclo
    else
        radio = radio_input; %Asigna radio si se encuentra dentro del rango
        otro_input = 1; %Rompe el ciclo (while NOT verdadero se vuelve while falso)
    end
end

otro_input2 = 0;
while ~otro_input2
    densidad_input = input('Densidad del aire (kg/m^3): ');
    if densidad_input < 1.1 || densidad_input > 1.3 %Rango de densidad
        disp('Densidad está fuera del rango 1.1-1.3') %Mensaje de error
        otro_input2 = 0; %Continua el ciclo
    else
        densidad = densidad_input; %Asigna densidad si se encuentra dentro del rango
        otro_input2 = 1; %Rompe el ciclo
    end
end

area = pi * radio^2; %Área de la esfera
volumen = (4/3) * pi * radio^3; %Volumen de la esfera
densidad_obj = 1500; %Lo obtuvimos de nuestra investigación (kg/m^3)
masa = densidad_obj * volumen; %Masa del objeto

v0x = v0 * cosd(angulo); %Componente en x de la velocidad inicial
v0y = v0 * sind(angulo); %Componente en y de la velocidad inicial

drag = -1; %Drag inicial
constante = 0.5 * area * 0.47 * densidad; %0.47 es el coeficiente de arrastre frontal para esferas
a0y = ((drag * constante * (v0y^2))/ masa) + g; %Fórmula para aceleración inicial en y
a0x = (-constante * v0x^2) / masa; %Fórmula para aceleración inicial en x


%--------------------------------------------------
%Trayectoria sin fricción

contador = 1; %Contador de pasos

vyf = v0y; %Valor acumulado que resultará en la velocidad en y final
vy(1) = v0y; %Primer valor de serie 'velocidad en y' es la velocidad inicial en y
yf = 0; %Posición en y empieza en 0

%Método de Euler para valores en y
for i = 1:999
    vyf = vyf + g * timestep; %La velocidad en y será la suma de la velocidad anterior más la gravedad por el timestep
    vy(i+1) = vyf; %La siguiente posición en la serie 'velocidad en y' será la nueva velocidad en y
    yf = yf + vy(i) * timestep; %Posición en y será suma de posición anterior más la velocidad en y actual por timestep
    y(i+1) = yf; %La siguiente posición en la serie 'posiciones en y' será la nueva posición en y
    contador = contador + 1; %Agrega el número de pasos
    if y(i+1) <= -y0 %Terminar ciclo cuando siguiente posición en y sea igual o menor a la posición inicial en y negativa
        break
    end
end

vx = v0x; %Valor de serie 'velocidad en x' es la velocidad inicial en x
xf = 0; %Posición en x empieza en 0

%Método de Euler para valores en x
for i = 1:contador-1 %Repetir ciclo por la cantidad de pasos que dio y
    xf = xf + vx * timestep; %Posición en x será suma de posición anterior más la velocidad en x actual por timestep
    x(i+1) = xf; %La siguiente posición en la serie 'posiciones en x' será la nueva posición en x
end

%--------------------------------------------------
%Parámetros de salida

tiempo = (contador - 1) * timestep; %Tiempo final es la cantidad de pasos por timestep
alcancemax = max(x) + x0; %Suma de valor máximo de la serie 'posiciones en x' más la posición inicial en x
alturamax = max(y) + y0; %Suma de valor máximo de la serie 'posiciones en y' más la posición inicial en y
velocidadf = sqrt((v0x)^2 + (vyf^2)); %Vector resultante de velocidad final en x y velocidad final en y
angulof = rad2deg(atan(velocidadf / v0x)); %Ángulo de vector resultante respecto al eje horizontal

disp(' ')
disp('Parámetros de salida (Euler sin fricción)')
salida = ['El tiempo de vuelo es de: ', num2str(tiempo), ' s'];
disp(salida)
salida1 = ['El alcance máximo es de: ', num2str(alcancemax), ' m'];
disp(salida1)
salida2 = ['La altura máxima es de: ', num2str(alturamax), ' m'];
disp(salida2)
salida3 = ['La velocidad de impacto es de: ', num2str(velocidadf), ' m/s'];
disp(salida3)
salida4 = ['El ángulo de impacto es de: ', num2str(angulof), ' grados'];
disp(salida4)

%--------------------------------------------------
%Gráfica (Azul)

vx(1:contador) = v0x; %Crea matriz de velocidades en x (constantes)
ax(1:contador) = 0; %Crea matriz de aceleraciones en x (constantes)
ay(1:contador) = g; %Crea matriz de aceleraciones en y (constantes)

plot(x, y, 'k'); %Crea gráfica inicial para estirar la visibilidad del cuadro (sino MatLab hará zoom en cada punto)
hold on
axis tight; %Ajusta el cuadro de visibilidad
imagen = imread('volcan.png'); %Lee imagen volcan
h = image(xlim, flip(ylim), imagen); %Ajusta imagen a bordes de x y y, flip (sino MatLab la adjunta de cabeza)
uistack(h,'bottom') %Función para agregar el componente al cuadro, lo apega al fondo

for k = 1:contador %Por cada paso (simula tiempo de trayectoria real)
    sf = scatter(x(k),y(k), '.b'); %Crea scatter plot con posiciones en x y en y por cada punto
    dtvx = dataTipTextRow('VX',vx(k)); %Crea una etiqueta con el valor de velocidad en x en cada punto
    sf.DataTipTemplate.DataTipRows(end+1) = dtvx; %Agrega etiqueta a lista de etiquetas desplegables
    dtvy = dataTipTextRow('VY',vy(k)); %Etiqueta vy
    sf.DataTipTemplate.DataTipRows(end+1) = dtvy;
    dtax = dataTipTextRow('AX',ax(k)); %Etiqueta ax
    sf.DataTipTemplate.DataTipRows(end+1) = dtax;
    dtay = dataTipTextRow('AY',ay(k)); %Etiqueta ay
    sf.DataTipTemplate.DataTipRows(end+1) = dtay;
    pause(timestep-0.01); %Espera un timestep, resta 0.01 segundos para compensar por el tiempo que tarda MatLab en procesar
end


% --------------------------------------------------
% Trayectoria con fricción

clear vyf %Borra todos los datos anteriores
clear vy
clear yf
clear vx
clear xf
clear ax
clear contador

contador = 1;

ay = a0y; %Serie de 'aceleración en y' que empieza con la aceleración inicial en y
vy(1) = v0y;
vyf = v0y; 
yf = 0;

%Método de Euler para valores en y
for i = 1:999
    if vy > 0 %Cuando vy es menor a 0 drag cambia de signo
        drag = -1;
    else
        drag = 1;
    end
    vyf = vyf + ay(i) * timestep; %MDE Velocidad en y
    vy(i+1) = vyf;
    ay(i+1) = ((drag * constante * (vy(i)^2) + masa * g)/ masa); %MDE Aceleración en y
    yf = yf + vy(i) * timestep; %MDE Posición en y
    y(i+1) = yf;
    contador = contador + 1;
    if y(i+1) <= -y0
        break
    end
end

ax = a0x; %Serie de 'aceleración en x' que empieza con la aceleración inicial en x
vx(1) = v0x; %Primer valor de serie 'velocidad en x' es la velocidad inicial en x
vxf = v0x;
xf = 0;

%Método de Euler para valores en x
for i = 1:contador-1
    vxf = vxf + ax(i) * timestep; %MDE Velocidad en x
    vx(i+1) = vxf;
    ax(i+1) = ((-constante * vx(i)^2) / masa); %MDE Aceleración en x
    xf = xf + vx(i) * timestep; %MDE Posición en x
    x(i+1) = xf;
end

%--------------------------------------------------
%Parámetros de salida

clear tiempo
clear alcancemax
clear alturamax
clear velocidadf
clear angulof

tiempo = (contador - 1) * timestep;
alcancemax = max(x) + x0;
alturamax = max(y) + y0;
velocidadf = sqrt((vxf)^2 + (vyf^2));
angulof = rad2deg(atan(velocidadf / vxf));

disp(' ')
disp('Parámetros de salida (Euler con fricción)')
salida = ['El tiempo de vuelo es de: ', num2str(tiempo), ' s'];
disp(salida)
salida1 = ['El alcance máximo es de: ', num2str(alcancemax), ' m'];
disp(salida1)
salida2 = ['La altura máxima es de: ', num2str(alturamax), ' m'];
disp(salida2)
salida3 = ['La velocidad de impacto es de: ', num2str(velocidadf), ' m/s'];
disp(salida3)
salida4 = ['El ángulo de impacto es de: ', num2str(angulof), ' grados'];
disp(salida4)

%--------------------------------------------------
%Gráfica (Roja)

for k = 1:contador
    cf = scatter(x(k),y(k), '.r'); %Crea un nuevo scatter plot rojo
    dtvx = dataTipTextRow('VX',vx(k));
    cf.DataTipTemplate.DataTipRows(end+1) = dtvx;
    dtvy = dataTipTextRow('VY',vy(k));
    cf.DataTipTemplate.DataTipRows(end+1) = dtvy;
    dtax = dataTipTextRow('AX',ax(k));
    cf.DataTipTemplate.DataTipRows(end+1) = dtax;
    dtay = dataTipTextRow('AY',ay(k));
    cf.DataTipTemplate.DataTipRows(end+1) = dtay;
    pause(timestep-0.01);
end

hold off

%Funciones de DataTip, uistack, y scatter obtenidas el 19 de octubre del 2021 de:
%MathWorks. (2021). MATLAB Documentation. https://www.mathworks.com/help/matlab/index.html