// Valeria López Barcelata A00833578
// Avance 3

#include "Series.hpp"
using namespace std;

// Constructores de la clase
Series::Series(){
  cantidadSeries = 0;
}

// Métodos modificadores
void Series::setCantidadSeries(int _cantidadSeries){
  cantidadSeries = _cantidadSeries;
}

// Métodos de acceso
int Series::getCantidadSeries(){
  return cantidadSeries;
}

// Otros métodos
void Series::addSerieAlArreglo(Serie _serie){
  if (cantidadSeries < 100){
    arrSeries[cantidadSeries] = _serie;
    cantidadSeries++;
  }
  else{
    cout << "No se pudo añadir la serie: \n" << _serie.str() << endl;
  }
}
void Series::calcularCalificacionPromedioSerie(){
  for (int indice = 0; indice < cantidadSeries; indice++){
    arrSeries[indice].calculaCalificacionPromedio();
  }
}

// Función para leer los archivos dentro de la misma carpeta, "Series.csv" y "Episodios.csv," se separan los datos mediante ',' y se asignan como los atributos de cada serie, al igual que se asignan todos los episodios a sus series correspondientes

void Series::leerArchivo(){
  string linea;
  string dato;
  int index;
  int columna;
  Episodio ep;
  Serie serie;
  ifstream lectura;

  index = 0;
  lectura.open("Series.csv", ios::in);
  while (getline(lectura, linea)){
    cout << linea << endl;
    stringstream renglon{linea};
    columna = 0;

    while (getline(renglon, dato, ',')){
      switch (columna++){
        case 0:
          serie.setID(dato);
          break;
        case 1:
          serie.setTitulo(dato);
          break;
        case 2:
          serie.setDuracion(stoi(dato));
          break;
        case 3:
          serie.setGenero(dato);
          break;
        case 4:
          serie.setCalificacion(stod(dato));
          break;
        case 5:
          serie.setCantidadEpisodios(0);
          break;
      }
    }
    cout << serie.str() << endl;
    addSerieAlArreglo(serie);
  }
  lectura.close();

  index = 0;
  lectura.open("Episodios.csv", ios::in);
  while (getline(lectura, linea)){
    cout << linea << endl;
    stringstream renglon{linea};
    columna = 0;

    while (getline(renglon, dato, ',')){
      switch (columna++){
        case 0:
          index = stoi(dato) - 100;
          break;
        case 1:
          ep.setTitulo(dato);
          break;
        case 2:
          ep.setTemporada(stoi(dato));
          break;
        case 3:
          ep.setCalificacion(stod(dato));
          break;
      }
    }
    arrSeries[index].addEpisodio(ep);
  }
  lectura.close();
}

// Busca en cada espacio del arreglo géneros para confirmar si ya existe el género, si existe se agrega al contador la cantidad de instancias que este ocurre, se agrega una frecuencia al acumulador, y se retorna el valor de su posición
// Si el género no existe actualmente en el arreglo de géneros, se agrega una frecuencia al acumulador, se incrementa la cantidad de géneros en total, el contador comienza en 1 al ser su primera instancia, y se retorna el valor de su nueva posición

int existeGenero(string genero, string arrGeneros[], int frecuencias[], int &cantidad, int &contador, int &acum){
  for(int iGeneros = 0; iGeneros < cantidad; iGeneros++){
    
    if (arrGeneros[iGeneros] == genero){
      contador = frecuencias[iGeneros];
      contador++;
      acum++;
      return iGeneros;
    }
  }
  arrGeneros[cantidad] = genero;
  contador = 1;
  acum++;
  return cantidad++;
}

// Se despliegan todas las series y se distribuyen las instancias de cada género en el arreglo frecuencias, se calculan las frecuencias relativas y se despliegan los resultados junto con la calificación promedio de todas las series

void Series::reporteFrecuenciasYPromedioSeries(){
  string genero;
  string generos[100];
  int posicionGenero;
  int cantidadGeneros = 0;
  int contador = 0;
  int acum = 0;
  int frecuencias[] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
  double acumPromedio = 0;

  cout << "\nReporte de Todas las Series\n"
  << "Frecuencias Absolutas por Género, Frecuencias Relativas Por Género\n"
  << "y promedio de todas las series en existencia\n" << endl;

  for (int indice = 0; indice < cantidadSeries; indice++){
    cout << arrSeries[indice].str() << endl;
    acumPromedio = acumPromedio + arrSeries[indice].getCalificacion();
    genero = generos[indice] = arrSeries[indice].getGenero();
    posicionGenero = existeGenero(genero, generos, frecuencias, cantidadGeneros, contador, acum);
    frecuencias[posicionGenero] = contador;
  }
  cout << "Tabla de Frecuencias por Género\n";
  cout << "Género        Frecuencia     Frecuencia Relativa\n";

  for (int indice = 0; indice < cantidadGeneros; indice++){
    double frecuenciaRelativa = frecuencias[indice] * 100 / cantidadSeries;
    cout << generos[indice] << setfill('.') << setw(15) << frecuencias[indice]
    << setfill(' ') << setw(15) << frecuenciaRelativa << "%" << endl;
  }
  cout << "Total de frecuencias = " << acum << endl
  << "Total de series = " << cantidadSeries << endl;

  if (cantidadSeries > 0){
    cout << "Calificación Promedio de Todas las Series: " << acumPromedio / cantidadSeries << endl;
  }
  else{
    cout << "No se pudo calcular la calificación promedio" << endl;
  }
}