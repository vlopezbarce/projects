clc;
clear;

%% Reto Fase 2. Gráficas
% Modelación computacional de sistemas electromagnéticos 

% Equipo 4: Not Gauss

% Integrantes:
% Marco Antonio Rodríguez Amezcua - A00834672
% Manuel José Ortiz Urueña – A00832807
% Isabella Garduño Horneffer – A00833573
% Valeria López Barcelata – A00833578

%% Declaración de variables

m = 0.01; % Masa de la partícula (kg)
g  = 9.81; % Aceleración gravitacional (m/s^2)
U = 1000000; % Momento dipolar (Cm)
M = 4*pi*(10^-7); % Constante de permeabilidad (H/m)
a = 0.08; % Radio (m)
R = 9*(10^-5); % Resistencia (Ohms)

t0 = 0; % Tiempo inicial (s)
z0 = 10; % Altura (m)
tf = 4; % Tiempo final (después de 4 segundos)
h = 0.001; % Timestep

%% Resolviendo la Ecuación Diferencial de Segundo Orden

% 1. Se reescribe la ecuación utilizando odeToVectorField para convertir
% la ecuación diferencial de segundo orden en una ecuación de primer orden
% mediante el cambio de variable
syms z(t)
[V] = odeToVectorField(diff(z,2) == (-m*g - ((9*(a^4)*(U*M)^2) / (4*R)) * (z^2 / (z^2 + a^2)^5) * diff(z)) / m);

% 2. Se convierte la expresión simbólica en una función de Matlab
% con variables incógnitas t y Y (t respecto al tiempo y Y es el resultado
% del cambio de variable, donde Y1 es z y Y2 es dz/dt)
M = matlabFunction(V,'vars', {'t','Y'});

% 3. Se utiliza la función ode45 para resolver el sistema de ecuaciones,
% basándose en la fórmula de Runge-Kutta para Cuarto y Quinto Orden
[t,y] = ode45(M,[t0 tf],[z0 0]);

% 4. Debido a que este método nos proporciona las soluciones para z y dz/dt,
% se establecen los vectores para la posición y la velocidad respectivamente
z = y(:,1);
v = y(:,2);

% 5. Se realiza el cálculo para obtener la aceleración por dv/dt
acel = diff(v)./diff(t);
acel(end+1,1) = acel(end,1); % Se ajusta el tamaño del vector

% 6. Se obtiene la fuerza por la fórmula masa * aceleración
fuerza = m .* acel;

%% Graficación

figure('Name','Movimiento de un Dipolo Frenado por Acción Magnética')
subplot(2,2,1)
plot(t,z,'-k','LineWidth',1)
title('1. Posición')
xlabel('Tiempo (s)')
ylabel('Posición (m)')
legend('Posición en z respecto a t')
grid on

subplot(2,2,2)
plot(t,v,'-b','LineWidth',1)
title('2. Velocidad')
xlabel('Tiempo (s)')
ylabel('Velocidad (m/s)')
legend('Velocidad como dz/dt')
grid on

subplot(2,2,3)
plot(t,acel,'-r','LineWidth',1)
title('3. Aceleración')
xlabel('Tiempo (s)')
ylabel('Aceleración (m/s^2)')
legend('Aceleración como dv/dt')
grid on

subplot(2,2,4)
plot(t,fuerza,'-g','LineWidth',1)
title('4. Fuerza')
xlabel('Tiempo (s)')
ylabel('Fuerza (N)')
legend('Fuerza como masa * aceleración')
grid on

%% Referencias

% MathWorks. (2022). ode45. Obtenido de Mathworks: https://la.mathworks.com/help/matlab/ref/ode45.html
% MathWorks. (2022). Solve a Second-Order Differential Equation Numerically. Obtenido de Mathworks: https://la.mathworks.com/help/symbolic/solve-differential-equation-numerically-1.html