// Valeria López Barcelata A00833578
// Proyecto Integrador (Situación Problema)

#ifndef Episodio_h
#define Episodio_h
#include <iostream>
using namespace std;

class Episodio{
private:
  string titulo;
  int temporada;
  double calificacion;

public:
  Episodio();
  Episodio(string _titulo, int _temporada, double _calificacion);
  string getTitulo();
  int getTemporada();
  double getCalificacion();
  void setTitulo(string _titulo);
  void setTemporada(int _temporada);
  void setCalificacion(double _calificacion);
  void mostrar();
};

// Métodos constructores
Episodio::Episodio(){
  titulo = " ";
  temporada = 0;
  calificacion = 0;
}
Episodio::Episodio(string _titulo, int _temporada, double _calificacion){
  titulo = _titulo;
  temporada = _temporada;
  calificacion = _calificacion;
}

// Métodos de acceso
string Episodio::getTitulo(){
  return titulo;
}
int Episodio::getTemporada(){
  return temporada;
}
double Episodio::getCalificacion(){
  return calificacion;
}

// Métodos modificadores
void Episodio::setTitulo(string _titulo){
  titulo = _titulo;
}
void Episodio::setTemporada(int _temporada){
  temporada = _temporada;
}
void Episodio::setCalificacion(double _calificacion){
  calificacion = _calificacion;
}

// Otros métodos
void Episodio::mostrar(){
  cout << "T" << temporada << " " << titulo << " " << calificacion << "/5"
       << endl;
}

#endif
