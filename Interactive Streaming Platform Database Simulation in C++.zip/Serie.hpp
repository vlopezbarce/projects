// Valeria López Barcelata A00833578
// Avance 3

#ifndef Serie_hpp
#define Serie_hpp

#include <iostream>
#include <stdio.h>
#include <string>
#include "Episodio.hpp"
using namespace std;

class Serie{
  private:
    string id;
    string titulo;
    string genero;
    int duracion;
    int cantEpisodios;
    int numEpisodio;
    double calificacionPromedio;
    Episodio episodios[5];

  public:
    // Constructores de la clase
    Serie();
    Serie(string _id, string _titulo, string _genero, int _duracion, int _cantEpisodios, double _calificacionPromedio, int _numEpisodio, Episodio _episodios);
    
    // Métodos modificadores - cambiar el valor de un atributo
    void setID(string _id);
    void setTitulo(string _titulo);
    void setGenero(string _genero);
    void setDuracion(int _duracion);
    void setCantidadEpisodios(int _cantEpisodios);
    void setCalificacion(double _calificacionPromedio);
    void setEpisodio(int &_numEpisodio, Episodio _episodios);
    void calculaCalificacionPromedio();
    void addEpisodio(Episodio _episodios);
    void delEpisodio(Episodio _episodios);

    // Métodos de acceso - retornan el valor de un atributo
    string getID();
    string getTitulo();
    string getGenero();
    int getDuracion();
    int getCantidadEpisodios();
    double getCalificacion();
    Episodio getEpisodio(int &_numEpisodio);

    // Método que retorna todos los atributos concatenados y separados por ,
    string str();
};

#endif